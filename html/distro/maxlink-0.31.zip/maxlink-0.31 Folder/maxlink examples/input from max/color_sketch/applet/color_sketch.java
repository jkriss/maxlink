import jk.*; import com.cycling74.io.*; import com.cycling74.max.*; import com.cycling74.util.*; import com.cycling74.msp.*; import com.cycling74.mxjedit.*; import com.cycling74.net.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; import netscape.javascript.*; import gnu.io.*; import javax.sound.midi.*; import javax.sound.midi.spi.*; import javax.sound.sampled.*; import javax.sound.sampled.spi.*; public class color_sketch extends BApplet {// set the background color from Max
// jkriss ~ 28 july 2004

// Open "color picker.pat" in the MaxLink examples folder 
// to control the color.

MaxLink link = new MaxLink(this,"color_sketch");

// these must be public
public float r,g,b;

void setup() {
  size(250,250);
  link.declareInlet("r");
  link.declareInlet("g");
  link.declareInlet("b");
}

void loop() {
  background(r,g,b);
}
}