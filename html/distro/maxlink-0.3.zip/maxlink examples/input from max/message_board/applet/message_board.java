import jk.*; import com.cycling74.io.*; import com.cycling74.max.*; import com.cycling74.util.*; import com.cycling74.msp.*; import com.cycling74.mxjedit.*; import com.cycling74.net.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; import netscape.javascript.*; import gnu.io.*; import javax.sound.midi.*; import javax.sound.midi.spi.*; import javax.sound.sampled.*; import javax.sound.sampled.spi.*; public class message_board extends BApplet {// jkriss ~ 31 july 2004

// This sketch demonstrates how to use setter functions
// to handle input from Max and how to make functions
// accessible from Max.

MaxLink link = new MaxLink(this, "message_board");

String oldMessage = "";
String message = "";
int messageCount = 0;
BFont f;

void setup() {
  size(500, 120);
  background(20);
  f = loadFont("Meta-Bold.vlw.gz"); 
  
  link.declareInlet("message", "setMessage");
  
  link.declareMaxFunction("erase");
}

void loop() {
  drawMessage();
}

// this method must be public
public void setMessage(String newMessage) {
  messageCount++;
  link.output(messageCount);
  oldMessage = message;
  message = newMessage;
}

// this method must be public, too
public void erase() {
  oldMessage = "";
  message = "";
  messageCount = 0;
  link.output(messageCount);
}

void drawMessage() {
  background(20);
  textFont(f, 44); 
  text(message, 35, 50);
  
  textFont(f, 22);
  if (oldMessage != "") text("previous message: " + oldMessage, 37, 80);
}

}